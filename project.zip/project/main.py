import threading
import time
import math
import wave
import struct
import os
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.utils import platform as kivy_platform
from kivy.core.window import Window
from kivy.animation import Animation

try:
    from kivy.core.audio import SoundLoader
except Exception:
    SoundLoader = None

from tasks import get_random_task, check_answer as verify_answer


# ── Генерируем beep.wav если его нет ──────────────────────────────────────────
def ensure_beep_wav(path="beep.wav"):
    if os.path.exists(path):
        return
    freq, duration, volume, rate = 880, 0.8, 0.6, 44100
    n = int(rate * duration)
    with wave.open(path, "w") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(rate)
        for i in range(n):
            t = i / rate
            # Нарастание громкости
            env = min(1.0, t / 0.05) * max(0.0, 1 - (t - 0.6) / 0.2)
            val = int(volume * env * 32767 * math.sin(2 * math.pi * freq * t))
            f.writeframes(struct.pack("<h", val))


#UI виджет
class RootLayout(BoxLayout):
    pass


#Основное приложение
class SmartAlarmApp(App):

    def build(self):
        #Тёмная тема
        Window.clearcolor = (0.08, 0.08, 0.12, 1)
        if kivy_platform not in ("android", "ios"):
            Window.size = (420, 720)

        self.alarm_time: str | None = None
        self.alarm_active = False
        self.current_task: dict | None = None
        self._sound = None
        self._sound_stop = threading.Event()
        self._blink_event = None

        ensure_beep_wav()
        return RootLayout()

    #ЧАСЫ
    def on_start(self):
        Clock.schedule_interval(self._tick, 1)

    def _tick(self, dt):
        now = datetime.now()
        self.root.ids.clock_label.text = now.strftime("%H:%M:%S")
        if (
            self.alarm_time
            and not self.alarm_active
            and now.strftime("%H:%M") == self.alarm_time
        ):
            self._fire_alarm()

    #УСТАНОВИТЬ ИЛИ ОТМЕНИТЬ
    def set_alarm(self):
        raw = self.root.ids.alarm_input.text.strip()
        #Принимаем форматы: "730", "7:30", "07:30"
        raw = raw.replace(".", ":").replace("-", ":").replace(" ", "")
        if ":" not in raw and len(raw) in (3, 4):
            raw = raw[:-2] + ":" + raw[-2:]
        try:
            datetime.strptime(raw, "%H:%M")
        except ValueError:
            self._set_status("❌ Неверный формат. Введите ЧЧ:ММ", (1, 0.3, 0.3, 1))
            return

        self.alarm_time = raw
        self.alarm_active = False
        self._set_status(f"✅ Будильник установлен на {raw}", (0.3, 1, 0.5, 1))
        self.root.ids.cancel_btn.opacity = 1
        self.root.ids.cancel_btn.disabled = False

    def cancel_alarm(self):
        self.alarm_time = None
        self.alarm_active = False
        self._stop_sound()
        self._hide_task_screen()
        self._set_status("Будильник не установлен", (0.6, 0.6, 0.6, 1))
        self.root.ids.cancel_btn.opacity = 0
        self.root.ids.cancel_btn.disabled = True

    #СРАБАТЫВАНИЕ
    def _fire_alarm(self):
        self.alarm_active = True
        self.current_task = get_random_task()
        self._show_task()
        self._start_sound()
        self._start_blink()

    def _show_task(self):
        ids = self.root.ids
        t = self.current_task
        ids.task_subject.text = f"📚 {t['subject']}"
        ids.task_question.text = t["question"]
        ids.answer_input.text = ""
        ids.result_label.text = "Реши задачу — будильник замолчит!"
        ids.result_label.color = (1, 0.85, 0.3, 1)
        ids.task_screen.opacity = 1
        #Анимация появления
        anim = Animation(opacity=1, duration=0.4)
        anim.start(ids.task_screen)

    def _hide_task_screen(self):
        anim = Animation(opacity=0, duration=0.5)
        anim.start(self.root.ids.task_screen)

    #ПРОВЕРКА ОТВЕТА
    def check_answer(self):
        if not self.current_task or not self.alarm_active:
            return
        user_ans = self.root.ids.answer_input.text
        if verify_answer(self.current_task, user_ans):
            self.root.ids.result_label.text = "🎉 Верно! Будильник выключен!"
            self.root.ids.result_label.color = (0.3, 1, 0.4, 1)
            self._stop_alarm()
        else:
            self.root.ids.result_label.text = "❌ Неверно! Думай ещё..."
            self.root.ids.result_label.color = (1, 0.3, 0.3, 1)
            #Вибрация на Android
            if kivy_platform == "android":
                try:
                    from android.permissions import request_permissions, Permission
                    from jnius import autoclass
                    Vibrator = autoclass("android.os.Vibrator")
                    PythonActivity = autoclass("org.kivy.android.PythonActivity")
                    v = PythonActivity.mActivity.getSystemService("vibrator")
                    v.vibrate(300)
                except Exception:
                    pass

    def show_hint(self):
        if self.current_task:
            self.root.ids.result_label.text = f"💡 {self.current_task['hint']}"
            self.root.ids.result_label.color = (1, 0.85, 0.3, 1)

    def next_task(self):
        """Дать другую задачу (но звук не выключается!)"""
        if self.alarm_active:
            self.current_task = get_random_task()
            self._show_task()

    #ВЫКЛЮЧЕНИЕ БУДИЛЬНИКА
    def _stop_alarm(self):
        self.alarm_active = False
        self._stop_sound()
        self._stop_blink()
        Clock.schedule_once(lambda dt: self._hide_task_screen(), 1.5)
        Clock.schedule_once(lambda dt: self.cancel_alarm(), 2.0)

    #ЗВУК
    def _start_sound(self):
        self._sound_stop.clear()
        t = threading.Thread(target=self._sound_loop, daemon=True)
        t.start()

    def _sound_loop(self):
        while not self._sound_stop.is_set():
            #Kivy SoundLoader нужно вызывать из главного потока — планируем
            Clock.schedule_once(self._play_once, 0)
            time.sleep(1.2)

    def _play_once(self, dt):
        if self._sound_stop.is_set():
            return
        if SoundLoader is None:
            return
        sound = SoundLoader.load("beep.wav")
        if sound:
            sound.play()

    def _stop_sound(self):
        self._sound_stop.set()

    #МИГАНИЕ ЗАГОЛОВКА
    def _start_blink(self):
        self._blink_state = True
        self._blink_event = Clock.schedule_interval(self._blink, 0.6)

    def _blink(self, dt):
        label = self.root.ids.alarm_title
        self._blink_state = not self._blink_state
        label.color = (1, 0.35, 0.35, 1) if self._blink_state else (1, 0.7, 0.1, 1)

    def _stop_blink(self):
        if self._blink_event:
            self._blink_event.cancel()
        self.root.ids.alarm_title.color = (1, 0.35, 0.35, 1)

    #УТИЛИТЫ
    def _set_status(self, text, color=(0.6, 0.6, 0.6, 1)):
        self.root.ids.status_label.text = text
        self.root.ids.status_label.color = color


SmartAlarmApp().run()